let util = require('../util.json');
let jwt = require('jsonwebtoken');
let config = require('../config.json');
var jwtFile = require('../controller/jwt');
let sharedService = require("./shared");


exports.testToken = function (req, res, next) {

    res.send("working");
}

exports.addClient = async function (req, res) {
    let requestBody = req.body;
    let requiredParams = ["username", "name", "email", "password", "name", "agent", "phoneNo"];
    let checkRequiredParams = await checkRequiredFields([requestBody], requiredParams);
    if (checkRequiredParams.validParams === true) {

        var encryptPassword = await sharedService.encryptPassword(requestBody[util.usersMapping.password]);

        var sqlValues = [];
        console.log("encryptPassword", encryptPassword)
        var values = [];
        values.push(requestBody[util.usersMapping.username]);
        values.push(requestBody[util.usersMapping.email]);
        values.push(encryptPassword);
        values.push(requestBody[util.usersMapping.name]);
        values.push(requestBody[util.usersMapping.phoneNo].toString());
        values.push(requestBody[util.usersMapping.address]);
        values.push(requestBody[util.usersMapping.state]);
        values.push(requestBody[util.usersMapping.city]);

        values.push(requestBody[util.usersMapping.agent]);
        values.push(0);

        sqlValues.push(values);


        var sqlQuery = "INSERT INTO clients (username,email,password,name,phoneNo,address,state,city,agent,isDeleted) VALUES ?";

        mysqldbconnection.query(sqlQuery, [sqlValues], function (error, rows) {
            if (error) {

                var message = error.errno === 1062 ? "Email already exists" : error.sqlMessage;
                let errorMessage = {
                    "code": 500,
                    "message": message
                }
                res.send(errorMessage);
            } else {
                var message = "User Added Successfully";
                let successMessage = {
                    "code": 200,
                    "message": message
                }
                res.send(successMessage);
            }
        });

    } else {
        var message = "No Records Found";
        let successMessage = {
            "code": 500,
            "message": checkRequiredParams.message || message
        }
        res.send(successMessage);
    }
}

function checkRequiredFields(data, requiredParams) {
    return new Promise(function (resolve, reject) {
        if (data === "") {
            resolve({
                "validParams": false,
                "message": "Data Not Found"
            });
        }
        let validParams = true;
        let rowNo = 0;
        let fieldName = "";

        for (let j = 0; j < data.length; j++) {
            for (let i = 0; i < requiredParams.length; i++) {
                if (data[j][requiredParams[i]] === undefined || data[j][requiredParams[i]] === "" || data[j][requiredParams[i]] === null) {
                    validParams = false;
                    rowNo = j + 1;
                    fieldName = requiredParams[i];
                    break;
                }
                if (!validParams) {
                    break;
                }
            }
        }

        let response = {
            "validParams": validParams,
            "message": "Required fields cannot be blank. " + fieldName + " is blank at row no " + rowNo
        }
        resolve(response);
    })
}

exports.editClient = function (req, res) {
    let requestBody = req.body;
    var modified = new Date();

    var values = [];
    // values.push(row[util.usersMapping.id]);
    values.push(requestBody[util.usersMapping.email]);
    values.push(requestBody[util.usersMapping.name]);
    values.push(requestBody[util.usersMapping.phoneNo].toString());
    values.push(requestBody[util.usersMapping.address]);
    values.push(requestBody[util.usersMapping.state]);
    values.push(requestBody[util.usersMapping.city]);

    values.push(requestBody[util.usersMapping.agent]);
    values.push(modified);
    values.push(req.body[util.usersMapping.id]);


    mysqldbconnection.query("UPDATE clients SET email = ? ,name = ?,phoneNo = ?,address = ?,state = ?, city = ?,agent = ?,modified = ? WHERE clientId = ?", values, function (error, rows, fields) {
        if (error) {
            res.send(util.errorOccured);
        } else {
            res.send(util.updatedSuccessfully);
        }
    })
}



exports.updatePassword = function (req, res) {

    mysqldbconnection.query('SELECT * FROM clients WHERE (clientId = ?)', [req.body.clientId], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            let passwordStatus = await sharedService.checkPassword(req.body.currentPassword, results[0].password);

            if (passwordStatus) {
                var modified = new Date();

                var values = [];
                // values.push(row[util.usersMapping.id]);
                var encryptPassword = await sharedService.encryptPassword(req.body.newPassword);

                values.push(encryptPassword);
                values.push(modified);
                values.push(req.body.clientId);


                mysqldbconnection.query("UPDATE clients SET password = ?,modified = ? WHERE clientId = ?", values, function (error, rows, fields) {
                    if (error) {
                        res.send(util.errorOccured)
                    } else {
                        res.send(util.updatedSuccessfully);

                    }
                })


            } else {
                res.send({
                    "code": 500,
                    "message": "The current password entered by you is incorrect."
                })
            }

        }
    })

}
exports.refreshToken = function (req, res) {

    const refreshToken = req.body.refreshToken;

    if (!refreshToken) {
        return res.status(403).send('Access is forbidden');
    }

    try {
        const newTokens = jwtService.refreshToken(refreshToken, res);

        res.send(newTokens);
    } catch (err) {
        const message = (err && err.message) || err;
        res.status(403).send(message);
    }

}

exports.disableClient = function (req, res) {
    let userId = req.body.userId;
    let inactive = req.body.inactive;
    let query = "UPDATE clients SET isDeleted = ? WHERE clientId = ?";
    mysqldbconnection.query(query, [inactive, userId], function (error, rows, fields) {
        if (error) {
            res.send(util.errorOccured);
        } else {
            res.send({
                "code": 200,
                "message": "User Updated Successfully"
            });
        }
    })
}

exports.getClientsByAgent = function (req, res) {
    let skip = req.body.skip;
    let limit = req.body.limit;
    mysqldbconnection.query(`SELECT * FROM clients WHERE (agent = ${req.body.agent})`, function (error, counts, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            mysqldbconnection.query(`SELECT * FROM clients WHERE (agent = ${req.body.agent}) LIMIT ${skip} ,${limit}`, function (error, results, fields) {
                if (error) {
                    console.log("error ocurred", error);
                    res.send(util.errorOccured);
                } else {
                    res.send({
                        "code": 200,
                        "result": results,
                        "totalCount": counts.length
                    });
                }

            })
        }
    })
}

exports.getClientLoginLogs = function (req, res) {
    var skip = req.body.skip;
    var limit = req.body.limit;
    mysqldbconnection.query('SELECT * FROM login_logs JOIN clients ON login_logs.id = clients.clientId WHERE type ="client" LIMIT ' + skip + ',' + limit, async function (error, results, fields) {
        if (error) {
            res.send(util.errorOccured);
        } else {
            res.send({
                "code": 200,
                "result": results
            });
        }
    });
}