let util = require('../util.json');
let jwt = require('jsonwebtoken');
let config = require('../config.json');
var jwtFile = require('../controller/jwt');
let sharedService = require('./shared');

function checkRequiredFields(data, requiredParams) {
    return new Promise(function (resolve, reject) {
        if (data === "") {
            resolve({
                "validParams": false,
                "message": "Data Not Found"
            });
        }
        let validParams = true;
        let rowNo = 0;
        let fieldName = "";

        for (let j = 0; j < data.length; j++) {
            for (let i = 0; i < requiredParams.length; i++) {
                if (data[j][requiredParams[i]] === undefined || data[j][requiredParams[i]] === "" || data[j][requiredParams[i]] === null) {
                    validParams = false;
                    rowNo = j + 1;
                    fieldName = requiredParams[i];
                    break;
                }
                if (!validParams) {
                    break;
                }
            }
        }

        let response = {
            "validParams": validParams,
            "message": "Required fields cannot be blank. " + fieldName + " is blank at row no " + rowNo
        }
        resolve(response);
    })
}

exports.adduser = async function (req, res) {
    console.log(req.body);
    let requestBody = req.body;
    let requiredParams = ["email", "password", "name", "parentId"];
    let checkRequiredParams = await checkRequiredFields([requestBody], requiredParams)

    if (checkRequiredParams.validParams === true) {
        var encryptPassword = await sharedService.encryptPassword(requestBody[util.usersMapping.password]);

        // console.log("encryptPassword",requestBody[util.usersMapping.password], encryptPassword);
        var sqlValues = [];

        var values = [];
        // values.push(row[util.usersMapping.id]);
        values.push(requestBody[util.usersMapping.email]);
        values.push(encryptPassword);
        values.push(requestBody[util.usersMapping.name]);
        values.push(requestBody[util.usersMapping.phoneNo].toString());
        values.push(requestBody[util.usersMapping.accessType]);
        values.push(requestBody[util.usersMapping.isDistributor]);
        values.push(requestBody[util.usersMapping.address]);
        values.push(requestBody[util.usersMapping.state]);
        values.push(requestBody[util.usersMapping.city]);

        values.push(requestBody[util.usersMapping.parentId]);
        values.push(0);

        sqlValues.push(values);


        var sqlQuery = "INSERT INTO users (email,password,name,phoneNo,accessType,isDistributor,address,state,city,parentId,isDeleted) VALUES ?";


        mysqldbconnection.query(sqlQuery, [sqlValues], function (error, rows) {
            if (error) {

                var message = error.errno === 1062 ? "Username already exists" : error.sqlMessage;
                let errorMessage = {
                    "code": 500,
                    "message": message
                }
                res.send(errorMessage);
            } else {
                var message = "User Added Successfully";
                let successMessage = {
                    "code": 200,
                    "message": message
                }
                res.send(successMessage);
            }
        });


    } else {
        var message = "No Records Found";
        let successMessage = {
            "code": 500,
            "message": checkRequiredParams.message || message
        }
        res.send(successMessage);
    }
}

exports.editUser = function (req, res) {
    let requestBody = req.body;
    var modified = new Date();

    var values = [];
    // values.push(row[util.usersMapping.id]);
    values.push(requestBody[util.usersMapping.email]);
    values.push(requestBody[util.usersMapping.name]);
    values.push(requestBody[util.usersMapping.phoneNo].toString());
    values.push(requestBody[util.usersMapping.accessType]);
    values.push(requestBody[util.usersMapping.isDistributor]);
    values.push(requestBody[util.usersMapping.address]);
    values.push(requestBody[util.usersMapping.state]);
    values.push(requestBody[util.usersMapping.city]);

    values.push(requestBody[util.usersMapping.parentId]);
    values.push(modified);
    values.push(req.body[util.usersMapping.id]);


    mysqldbconnection.query("UPDATE users SET email = ? ,name = ?,phoneNo = ?,accessType = ?,isDistributor = ?,address = ?,state = ?, city = ?, parentId = ?,modified = ? WHERE id = ?", values, function (error, rows, fields) {
        if (error) {
            res.send(util.errorOccured);
        } else {
            res.send(util.updatedSuccessfully);
        }
    })
}

exports.list = function (req, res) {
    var skip = req.body.skip;
    var limit = req.body.limit;
    mysqldbconnection.query('SELECT * FROM users', function (error, counts, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            mysqldbconnection.query('SELECT * FROM users  LIMIT ' + skip + ',' + limit, function (error, results, fields) {
                if (error) {
                    console.log("error ocurred", error);
                    res.send(util.errorOccured);
                } else {
                    results.forEach(element => {
                        delete element.password;
                    });
                    res.send({
                        "code": 200,
                        "result": results,
                        "totalCount": counts.length
                    });
                }
            });
        }
    })
}

exports.disableDistributor = async function (req, res) {
    let userId = req.body.userId;
    let inactive = req.body.inactive;

    mysqldbconnection.query('SELECT * FROM users WHERE parentId = ? AND isDeleted = ?', [userId, !inactive], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            console.log(results);
            if (results.length != 0) {
                await updateClients1(results, inactive);
                await updateChildUsers(results, inactive);
            }

            let query = "UPDATE users SET isDeleted = ? WHERE id = ?";

            // if(data) {
            mysqldbconnection.query(query, [inactive, userId], function (error, rows, fields) {
                if (error) {
                    res.send(util.errorOccured)
                } else {
                    res.send({
                        "code": 200,
                        "message": "User Updated Successfully"
                    });
                }
            })

        }
    })
}

exports.disableAgent = async function (req, res) {
    let userId = req.body.userId;
    let inactive = req.body.inactive;

    mysqldbconnection.query('SELECT * FROM users WHERE parentId = ? AND isDeleted = ?', [userId, !inactive], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            await updateClients(userId, inactive);

            let query = "UPDATE users SET isDeleted = ? WHERE id = ?";

            // if(data) {
            mysqldbconnection.query(query, [inactive, userId], function (error, rows, fields) {
                if (error) {
                    res.send(util.errorOccured)
                } else {
                    res.send({
                        "code": 200,
                        "message": "User Updated Successfully"
                    });
                }
            })
            // }
        }
    })
}

async function updateChildUsers(results, inactive) {
    console.log(results[0].id);
    for (let i = 0; i < results.length; i++) {
        await new Promise(resolve => {
            let query = "UPDATE users SET isDeleted = ? WHERE id = ?";
            mysqldbconnection.query(query, [inactive, results[i].id], function (error, rows, fields) {
                if (error) {
                    res.send(util.errorOccured);
                } else {
                    if (i == results.length - 1) {
                        resolve(true);
                    }
                }
            })
        });
    }
}

async function updateClients1(data, inactive) {
    for (let i = 0; i < data.length; i++) {
        // await new Promise(resolve => {
        mysqldbconnection.query('SELECT * FROM clients WHERE agent = ? AND isDeleted = ?', [data[i].id, !inactive], async function (error, results, fields) {
            if (error) {
                console.log("error ocurred", error);
                res.send(util.errorOccured);
            } else {
                console.log(results);
                for (let j = 0; j < results.length; j++) {
                    await new Promise(resolve => {
                        let query = "UPDATE clients SET isDeleted = ? WHERE agent = ?";
                        mysqldbconnection.query(query, [inactive, results[j].agent], function (error, rows, fields) {
                            if (error) {
                                res.send(util.errorOccured);
                            } else {
                                if (j == results.length - 1) {
                                    resolve(true);
                                }
                            }
                        })
                    });
                }
            }
        })
        // if (i == data.length - 1) {
        //     resolve(true);
        // }
        // })
    }
}

async function updateClients(data, inactive) {

    mysqldbconnection.query('SELECT * FROM clients WHERE agent = ? AND isDeleted = ?', [data, !inactive], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            console.log(results);
            for (let i = 0; i < results.length; i++) {
                await new Promise(resolve => {
                    let query = "UPDATE clients SET isDeleted = ? WHERE agent = ?";
                    mysqldbconnection.query(query, [inactive, results[i].agent], function (error, rows, fields) {
                        if (error) {
                            res.send(util.errorOccured);
                        } else {
                            if (i == results.length - 1) {
                                resolve(true);
                            }
                        }
                    })
                });
            }
        }
    })
}

exports.updatePassword = function (req, res) {


    mysqldbconnection.query('SELECT * FROM users WHERE (id = ?)', [req.body.id], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {

            // console.log(results[0],)
            let passwordStatus = await sharedService.checkPassword(req.body.currentPassword, results[0].password);
            // console.log( output);
            if (passwordStatus) {
                // console.log("password updated");
                var modified = new Date();

                var values = [];
                // values.push(row[util.usersMapping.id]);
                var encryptPassword = await sharedService.encryptPassword(req.body.newPassword);

                values.push(encryptPassword);
                values.push(modified);
                values.push(req.body[util.usersMapping.id]);

                mysqldbconnection.query("UPDATE users SET password = ?,modified = ? WHERE id = ?", values, function (error, rows, fields) {
                    if (error) {
                        res.send(util.errorOccured)
                    } else {
                        res.send(util.updatedSuccessfully);

                    }
                })



            } else {
                res.send({
                    "code": 500,
                    "message": "The current password entered by you is incorrect."
                })
            }



        }
    })

}

exports.getDistributors = function (req, res) {
    let skip = req.body.skip;
    let limit = req.body.limit;
    let name = req.body.name ? req.body.name.toLowerCase() : "";
    let email = req.body.email;
    let phoneNo = req.body.phoneNo;
    let status = req.body.status;
    let countQuery;
    let sqlQuery;
    if (name || status) {
        let filterQuery = " AND (LOWER(name) LIKE '%" + name + "%' OR LOWER(email) LIKE '%" + email + "%' OR phoneNo LIKE '%" + phoneNo + "%') HAVING isDeleted = " + status + ""
        countQuery = 'SELECT * FROM users WHERE  accessType = "AGENT" AND isDistributor = 1' + filterQuery + ' AND parentId = ?';
        sqlQuery = 'SELECT * FROM users WHERE  accessType = "AGENT" AND isDistributor = 1 AND parentId =' + req.body.id + filterQuery + '  LIMIT ' + skip + ',' + limit;
    } else {
        countQuery = 'SELECT * FROM users WHERE ( accessType = "AGENT" AND isDistributor = 1 AND parentId = ?)';
        sqlQuery = 'SELECT * FROM users WHERE accessType = "AGENT" AND isDistributor = 1 AND parentId =' + req.body.id + '  LIMIT ' + skip + ',' + limit;
    }

    console.log(sqlQuery);

    mysqldbconnection.query(countQuery, [req.body.id], function (error, counts, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {

            mysqldbconnection.query(sqlQuery, async function (error, results, fields) {
                if (error) {
                    console.log("error ocurred", error);
                    res.send(util.errorOccured);
                } else {
                    let result = await getConnectedAgents(results, counts.length);
                    let data = await getConnectedClients(result, counts.length);

                    console.log("data", data);
                    res.send({
                        "code": 200,
                        "result": data,
                        "totalCount": counts.length
                    });
                }
            });
        }
    })
}

async function getConnectedAgents(results, count) {
    console.log("result", results);
    return await new Promise(resolve => {
        for (let i = 0; i < results.length; i++) {

            let query = "SELECT * FROM users WHERE parentId = ?";
            mysqldbconnection.query(query, [results[i].id], function (error, rows, fields) {
                if (error) {
                    res.send(util.errorOccured);
                } else {
                    results[i].connectedAgents = rows.length;
                    console.log("result", results[i]);
                    if (i == results.length - 1) {
                        // return results;
                        resolve(results);
                    }
                }
            })

        }
    });
}

async function getConnectedClients(results, count) {
    return await new Promise(resolve => {
        for (let i = 0; i < results.length; i++) {
            let query = "SELECT * FROM clients WHERE agent = ?";
            mysqldbconnection.query(query, [results[i].id], function (error, rows, fields) {
                if (error) {
                    res.send(util.errorOccured);
                } else {
                    results[i].connectedClients = rows.length;
                    console.log("result1", rows.length);
                    if (i == results.length - 1) {
                        resolve(results);
                    }
                }
            })
        }
    });
}

exports.getAgents = function (req, res) {
    let skip = req.body.skip;
    let limit = req.body.limit;
    mysqldbconnection.query('SELECT * FROM users WHERE (isDeleted = 0 AND accessType = "AGENT" AND isDistributor = 0 AND parentId = ?)', [req.body.id], function (error, counts, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            mysqldbconnection.query('SELECT * FROM users WHERE isDeleted = 0 AND accessType = "AGENT" AND isDistributor = 0 AND parentId =' + req.body.id + '  LIMIT ' + skip + ',' + limit, async function (error, results, fields) {
                if (error) {
                    console.log("error ocurred", error);
                    res.send(util.errorOccured);
                } else {
                    let data;
                    if (results.length) {
                        data = await getConnectedClients(results, counts.length);
                    } else {
                        data = results;
                    }

                    res.send({
                        "code": 200,
                        "result": data,
                        "totalCount": counts.length
                    });
                }
            });
        }
    })
}

exports.getUserById = function (req, res) {
    mysqldbconnection.query('SELECT * FROM users WHERE id =' + req.body.id, async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send(util.errorOccured);
        } else {
            res.send({
                "code": 200,
                "result": results[0]
            });
        }
    });
}

exports.getUserLoginLogs = function (req, res) {
    var skip = req.body.skip;
    var limit = req.body.limit;
    mysqldbconnection.query('SELECT * FROM login_logs JOIN users ON login_logs.id = users.id WHERE type ="user" LIMIT ' + skip + ',' + limit, async function (error, results, fields) {
        if (error) {
            res.send(util.errorOccured);
        } else {
            res.send({
                "code": 200,
                "result": results
            });
        }
    });
}