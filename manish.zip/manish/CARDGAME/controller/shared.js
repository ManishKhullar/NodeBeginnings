let util = require("../util.json");
let config = require("../config.json");

var bcrypt = require('bcrypt');
var SHA256 = require("crypto-js/sha256");
var AES = require("crypto-js/aes");
var CryptoJS = require("crypto-js");

function insertUserLogs(data) {
    // let resultedObj = data;

    var sqlValues = [];

    var values = [];
    values.push(data.id);
    values.push(data.type);
    values.push(data.serial);
    values.push(data.model);
    values.push(data.brand);
    values.push(data.manufacturer);
    values.push(data.board);
    values.push(data.version_code);
    values.push(data.fingerprint);

    values.push(data.location);
    values.push(data.logindevice);
    values.push(data['user_agent']);
    values.push(data.origin);
    values.push(data.host);

    sqlValues.push(values);
    // console.log("values",values)
    let query = "INSERT INTO login_logs ( id,type,serial,model,brand,manufacturer,board,version_code,fingerprint, location, logindevice, user_agent, origin, host) VALUES ? "

    mysqldbconnection.query(query, [sqlValues], function (err, result) {
        if (err) {
            throw util.errorOccured
        } else {
            return null;
        }
        // console.log("Number of records inserted: " + result.affectedRows);
    });

}

function checkPassword(userPass, hash) {

    var bytes = CryptoJS.AES.decrypt(hash, config.jwtpwd);
    var decryptedData = (bytes.toString(CryptoJS.enc.Utf8));
    return decryptedData == userPass;

}

function encryptPassword(password) {


    return new Promise(function (resolve, reject) {
        var ciphertext = CryptoJS.AES.encrypt(password, config.jwtpwd).toString();

        if (ciphertext) {
            resolve(ciphertext);
        } else {

            reject(util.errorOccured);

        }

    });


    // bcrypt.hash(password, 10, function (err, hash) {

    //     // console.log(hash);
    //     if (err) {
    //         return callback(err);
    //     }
    //     return callback(hash);

    // });

}

function getPassword(hash) {
    var bytes = CryptoJS.AES.decrypt(hash, config.jwtpwd);
    var decryptedData = (bytes.toString(CryptoJS.enc.Utf8));
    return decryptedData;
}

function handleOnlineUser(state, userId) {
    let query = `update clients set isOnline=${state} where clientId=${userId}`;
    mysqldbconnection.query(query, function (error, result) {
        if (error) {
            return false;

        } else {
            return true;
        }
    })
}

module.exports = {
    insertUserLogs,
    encryptPassword,
    checkPassword,
    getPassword,
    handleOnlineUser
}