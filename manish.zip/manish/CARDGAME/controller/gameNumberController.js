let util = require('../util.json');
let jwt = require('jsonwebtoken');
let config = require('../config.json');
var jwtFile = require('../controller/jwt');
let sharedService = require("./shared");


function generateGameNumber(gameNameID) {

return new Promise(function (resolve,reject) {
    
    let query = `update game_number set gameNumber=gameNumber+1 where gameNameID=${gameNameID}`;
    mysqldbconnection.query(query, function (error, result) {
        if (error) {
            reject((util.errorOccured));
 
        } else {

            let query1 = `SELECT * , CONCAT(DATE_FORMAT(updated_at, "%Y%m%d"),gameNameID,gameNumber) as gameNumber  from game_number where gameNameID=${gameNameID}`;

            mysqldbconnection.query(query1, function (error1, result1) {
                if (error1) {

                    res.send(util.errorOccured);

                } else {
                    let sqlValues = [];
                    let values = [];
                    values.push(result1[0].gameNameID);
                    values.push(1);
                    values.push(result1[0].gameNumber);

                    sqlValues.push(values);

                    let creatNewGameQuery = `insert into game_list_status (gameNameID,status,gameNumber) values ?`;
                    mysqldbconnection.query(creatNewGameQuery, [sqlValues], function (gameError, gameResult) {
                        if (gameError) {

                            res.send(util.errorOccured);

                        } else {

                            let resultedObj = {
                                "gameNumber": result1[0].gameNumber,
                                "gameNameID": result1[0].gameNameID,
                                "id": gameResult.insertId,
                                "status": 1
                            }

                            resolve( resultedObj);
                        }
                    });






                }

            });

        }

    });

   
})
}

module.exports = {
    generateGameNumber
}