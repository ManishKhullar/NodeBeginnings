let util = require('../util.json');
let jwt = require('jsonwebtoken');
let config = require('../config.json');
var jwtFile = require('../controller/jwt');
let sharedService = require("./shared");
let generateGameNumber = require("./gameNumberController");
let insertTransaction = require("./transactionController");

exports.joinGame = function (req, res) {

    let gameNameID = req.body.gameNameID;
    let gameName = req.body.gameName;
    let clientId = req.body.clientId;
    let amount = req.body.amount;
    let gameType = req.body.gameType;

    let findUserBalance = `select balance from clients where clientId=${clientId}`;

    mysqldbconnection.query(findUserBalance, function (balanceError, balanceResult) {

        if (balanceError) {

            res.send(util.errorOccured);

        } else {

            if (balanceResult[0].balance >= amount) {

                let query = `select * from game_list_status where gameNameID=${gameNameID} and status=1`;

                mysqldbconnection.query(query, async function (error, result) {
                    if (error) {

                        res.send(util.errorOccured);

                    } else {

                        if (result.length != 0) {

                            let obj = {
                                amount: amount,
                                clientId: clientId,
                                gameType: gameType,
                                gameName: gameName,
                                ...result[0]
                            };
                            try {
                                await insertTransaction.insertDiceGameWinLossTransaction(obj);
                                res.send({
                                    code: 200,
                                    result: result[0]
                                });
                            } catch (tranError) {
                                // console.log("temp", tranError)
                                res.send(tranError);
                            }

                        } else {

                            try {
                                let tempData = await generateGameNumber.generateGameNumber(gameNameID);
                                let obj = {
                             
                                    amount: amount,
                                    clientId: clientId,
                                    gameType: gameType,
                                    ...tempData
                                };
                                await insertTransaction.insertDiceGameWinLossTransaction(obj);
                                res.send({
                                    code: 200,
                                    result: tempData
                                });
                            } catch (tranError) {
                                // console.log("temp", tranError)
                                res.send(tranError);
                            }

                        }

                    }
                });
            } else {
                res.send(util.insufficientBalance);
            }
        }


    });
}