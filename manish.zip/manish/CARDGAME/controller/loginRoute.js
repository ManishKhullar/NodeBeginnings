let util = require('../util.json');
let jwt = require('jsonwebtoken');
let config = require('../config.json');
var jwtFile = require('../controller/jwt');
let sharedService = require('./shared');

// client login
exports.clientLogin = async function (req, res) {

    var username = req.body.username;
    var password = req.body.password;
    // let data = req.body;
    // console.log(data)

    console.log(req.headers)


    mysqldbconnection.query('SELECT * FROM clients WHERE (username = ? AND isDeleted = 0)', [username], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send({
                "code": 400,
                "message": "error ocurred"
            })
        } else {
            if (results.length > 0) {


                let passwordStatus = await sharedService.checkPassword(password, results[0].password);


                if (passwordStatus) {
                    //  console.log("success");
                    delete results[0].password;

                    const payload = {
                        clientId: results[0].clientId
                    };
                    // const options = { expiresIn: "1h" };
                    // const secret = config.jwtpwd; //process.env.JWT_SECRET;
                    const token = await jwtFile.getAccessToken(payload) //jwt.sign(payload, secret, options);
                    const refreshToken = await jwtFile.getRefreshToken(results[0]);
                    req.body.type = "client";
                    req.body.id = results[0].clientId;




                    sharedService.insertUserLogs(req.body);
                    sharedService.handleOnlineUser(true, req.body.id);
                    res.send({
                        ...util.loginSuccessfull,
                        "result": results,
                        "accessToken": token,
                        "refreshToken": refreshToken
                    });
                } else {
                    let messageBody = {
                        "code": 500,
                        "message": util.invalidCredentials.message
                    }
                    res.send(messageBody);
                }



            } else {
                let messageBody = {
                    "code": 204,
                    "message": util.noRecordsFound.message
                }
                res.send(messageBody);
            }
        }
    });
};

// user login
exports.userLogin = function (req, res) {

    var email = req.body.email;
    var password = req.body.password;
    console.log(req.headers)


    mysqldbconnection.query('SELECT * FROM users WHERE (email = ? AND isDeleted = 0)', [email], async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send({
                "code": 400,
                "message": "error ocurred"
            })
        } else {
            if (results.length > 0) {
                let passwordStatus = await sharedService.checkPassword(password, results[0].password);

                if (passwordStatus) {
                    //  console.log("success");
                    delete results[0].password;

                    const payload = {
                        userId: results[0].id
                    };
                    // const options = {
                    //     expiresIn: "1h"
                    // };
                    // const secret = config.jwtpwd; //process.env.JWT_SECRET;
                    // const token = jwt.sign(payload, secret, options);
                    // const payload = {
                    //     clientId: results[0].clientId
                    // };
                    // const options = { expiresIn: "1h" };
                    // const secret = config.jwtpwd; //process.env.JWT_SECRET;
                    const token = await jwtFile.getAccessToken(payload) //jwt.sign(payload, secret, options);
                    const refreshToken = await jwtFile.getRefreshToken(results[0]);
                    req.body.type = "user";
                    req.body.id = results[0].id;

                    req.body.location = req.headers.location;
                    req.body.logindevice = req.headers.logindevice;
                    req.body['user_agent'] = req.headers['user-agent'];
                    req.body.origin = req.headers.origin;
                    req.body.host = req.headers.host;

                    sharedService.insertUserLogs(req.body);
                    // sharedService.insertUserLogs({type:"user",id:results[0].id});


                    res.send({
                        ...util.loginSuccessfull,
                        "result": results,
                        "accessToken": token,
                        "refreshToken": refreshToken
                    });
                } else {
                    let messageBody = {
                        "code": 500,
                        "message": util.invalidCredentials.message
                    }
                    res.send(messageBody);
                }

            } else {
                let messageBody = {
                    "code": 204,
                    "message": util.noRecordsFound.message
                }
                res.send(messageBody);
            }
        }
    });

};

exports.getUserPassword = function (req, res) {

    mysqldbconnection.query('SELECT * FROM users WHERE id=' + req.body.id, async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send({
                "code": 400,
                "message": "error ocurred"
            })
        } else {

            let pass = await sharedService.getPassword(results[0].password);

            res.send({
                "code": 200,
                results: pass
            })
        }
    });


}
// getClientPassword
exports.getClientPassword = function (req, res) {

    mysqldbconnection.query('SELECT * FROM clients WHERE clientId=' + req.body.id, async function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send({
                "code": 400,
                "message": "error ocurred"
            })
        } else {

            let pass = await sharedService.getPassword(results[0].password);

            res.send({
                "code": 200,
                results: pass
            })
        }
    });


}

exports.clientLogout = async function (req, res) {
    let data = await sharedService.handleOnlineUser(false, req.body.id);
    res.send({
        "code": 200,
        "message": "User logged out successfully"
    })
}