let util = require('../util.json');
let jwt = require('jsonwebtoken');
let config = require('../config.json');
var jwtFile = require('../controller/jwt');
let sharedService = require("./shared");

exports.manageTransaction = function (req, res) {

    var sqlValues = [];

    var values = [];
    values.push(req.body.userID);
    values.push(req.body.clientID);
    values.push(req.body.amount);
    values.push(req.body.transactionType);
    values.push(req.body.remark);

    sqlValues.push(values);


    var sqlQuery = "INSERT INTO transaction (userID,clientID,amount,transactionType,remark) VALUES ?";

    mysqldbconnection.query(sqlQuery, [sqlValues], function (error, rows) {
        if (error) {

            let errorMessage = {
                "code": 500,
                "message": util.errorOccured
            }
            res.send(errorMessage);
        } else {
            let message = "Transaction inserted Successfully";
            let successMessage = {
                "code": 200,
                "message": message
            }
            res.send(successMessage);
        }
    });

    // res.send(values);


}


exports.insertUserTransaction = function (req, res) {

    let fromTable = {
        table: 'users',
        id: "userID",
        whereId: 'id'

    };
    let toTable = {
        table: 'users',
        id: "userID",
        whereId: 'id'
    };
    // check from user balance is sufficient or not

    if (req.body.toUserType == 'client') {
        toTable.table = 'clients';
        toTable.id = 'clientID';
        toTable.whereId = 'clientId';
    }
    if (req.body.fromUserType == 'client') {
        fromTable.table = 'clients';
        fromTable.id = 'clientID';
        fromTable.whereId = 'clientId';
    }

    let findUserBalance = `select balance from ${fromTable.table} where ${fromTable.whereId}=${req.body.fromID}`;

    if (req.body.fromUserType == 'admin') {
        Promise.all([insertCreditedTransaction(req.body, toTable)]).then(function (err, values) {
            if (err) {
                res.send(err);
            } else {
                res.send(values);
            }
        });
    } else if (req.body.toUserType == 'admin') {
        Promise.all([insertDebitedTransaction(req.body, fromTable)]).then(function (err, values) {
            if (err) {
                res.send(err);
            } else {
                res.send(values);
            }
        });
    } else {

        mysqldbconnection.query(findUserBalance, function (error, rows) {
            if (error) {
                res.send(util.errorOccured);
            } else {

                if (rows[0].balance >= req.body.amount) {

                    Promise.all([insertCreditedTransaction(req.body, toTable), insertDebitedTransaction(req.body, fromTable)]).then(function (err, values) {
                        if (err) {
                            res.send(err);

                        } else {
                            res.send(values);

                        }
                    });
                } else {

                    res.send(util.insufficientBalance);
                }

            }
        });

    }

}





function insertCreditedTransaction(data, obj) {

    return new Promise(function (resolve, reject) {
        let values = [];
        let sqlValues = [];
        values.push(data.toID); // userID 
        values.push(data.fromID); //sender id 
        values.push(data.amount);
        values.push("ADD"); //transaction type
        values.push(`Money received from ${data.fromUserType} ${data.fromName} `); // remark
        // values.push(data.operationType);
        sqlValues.push(values);
        let creditQuery = `INSERT INTO transaction (${obj.id},fromID,amount,transactionType,remark) VALUES ?`;
        mysqldbconnection.query(creditQuery, [sqlValues], function (error, creditResult) {
            if (error) {

                reject(util.errorOccured);

            } else {

                let addUserAmount = `UPDATE ${obj.table}  SET balance = balance +${data.amount} WHERE ${obj.whereId}=${data.toID} ;`
                mysqldbconnection.query(addUserAmount, function (error1, userResult) {
                    if (error1) {

                        reject(util.errorOccured);

                    } else {

                        resolve(userResult);

                    }
                });
                resolve(creditResult);

            }
        });

    });
}

function insertDebitedTransaction(data, obj) {
    return new Promise(function (resolve, reject) {
        let values = [];
        let sqlValues = [];
        values.push(data.fromID); //userID receiver
        values.push(data.toID); // sender id  id
        values.push(data.amount);
        values.push("SUBTRACT"); // transaction type
        values.push(`Money transferred to  ${data.toUserType} ${data.toName} `); // remark
        // values.push(data.operationType);
        sqlValues.push(values);
        let debitQuery = `INSERT INTO transaction (${obj.id} ,toID,amount,transactionType,remark) VALUES ?`;

        mysqldbconnection.query(debitQuery, [sqlValues], function (error, debitResult) {
            if (error) {

                reject(util.errorOccured);

            } else {
                // if(data.toUserType)
                let debitUserAmount = `UPDATE ${obj.table}  SET balance = balance - ${data.amount} WHERE ${obj.whereId}=${data.fromID} ;`
                mysqldbconnection.query(debitUserAmount, function (error1, userResult) {
                    if (error1) {

                        reject(util.errorOccured);

                    } else {

                        resolve(userResult);

                    }
                });


            }
        });

    });
}


exports.getTransactionDetailsByUser = function (req, res) {

    let query = `SELECT GROUP_CONCAT(*), DATE_FORMAT(created_at, '%d-%m-%Y') as anyVariableName 
        FROM transaction where userID=1 GROUP BY anyVariableName;`;
    //`select date * from transaction where userId=1 GROUP BY created_at`;

    mysqldbconnection.query(query, function (error, result) {

        if (error) {

            res.send(util.errorOccured);
        } else {
            res.send(result);
        }

    });

}



exports.insertDiceGameWinLossTransaction = function (req, res) {
    // game type
    // 1. joining   2. winning   3.losing
    let data = req;
    console.log(req)
    return new Promise(function (resolve, reject) {

        let values = [];
        let sqlValues = [];

        values.push(data.clientId);
        values.push(data.amount);
        values.push(data.gameType); //transaction type
        values.push(data.gameType == "JOIN" ? `Joined A ${data.gameName} game by Rs.${data.amount}` : data.gameType == "WON" ? `Won Rs.${data.amount} In ${data.gameName} game.` : `Lose Rs.${data.amount} In ${data.gameName} game.`); // remark
        values.push(data.gameName);
        values.push(data.gameNumber);
        sqlValues.push(values);
        let creditQuery = `INSERT INTO transaction (fromID,amount,transactionType,remark,gameName,gameNumber) VALUES ?`;
        mysqldbconnection.query(creditQuery, [sqlValues], function (error, creditResult) {
            if (error) {

                reject((util.errorOccured));

            } else {
                let userAmount = '';
                if (data.gameType == "joining" || data.gameType == "losing") {
                    userAmount = `UPDATE clients  SET balance = balance -${data.amount} WHERE clientId=${data.clientId} ;`
                } else {
                    userAmount = `UPDATE clients  SET balance = balance +${data.amount} WHERE clientId=${data.clientId} ;`
                }
                mysqldbconnection.query(userAmount, function (error1, userResult) {
                    if (error1) {

                        reject(util.errorOccured);

                    } else {

                        resolve(userResult);

                    }
                });

            }
        });


    });
}

exports.getTransactions = function (req, res) {
    let skip = req.body.skip || 0;
    let limit = req.body.limit || 10;
    let query = `SELECT 
    any_value(DATE_FORMAT(created_at, '%d-%m-%Y')) as date,
    JSON_ARRAYAGG(json_object('amount',amount,'gameName',gameName,'gameNumber',gameNumber)) AS 'data'
    FROM coingames.transaction
    where clientID = ${req.body.id}
    LIMIT ${skip} , ${limit}
    GROUP BY DATE_FORMAT(created_at, '%d-%m-%Y');`;
    //`select date * from transaction where userId=1 GROUP BY created_at`;

    mysqldbconnection.query(query, function (error, result) {

        if (error) {

            res.send(util.errorOccured);
        } else {
            res.send(result);
        }

    });
}