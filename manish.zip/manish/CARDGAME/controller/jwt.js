const jwt = require('jsonwebtoken');

let config = require('../config.json');
let util = require("../util.json")
let jwtSecretString = config.jwtpwd;

let refreshTokenValidity = "20min";
let accessTokenValidity = "15min";

// access token generation
exports.getAccessToken = function getAccessToken(payload) {
    return jwtTokenGenerator(payload, accessTokenValidity);
}


function jwtTokenGenerator(payload, expiresIn) {

    return jwt.sign(payload,
        jwtSecretString, {
            expiresIn: expiresIn
        }
    );
}

function hasClientId(payload) {
    return payload.hasOwnProperty('clientId');
}

// generate refresh token
exports.getRefreshToken = async function getRefreshToken(payload) {
    let obj = {};
    let tableName = "";
    let key = "";
  
    if (hasClientId(payload)) {
        obj = {
            clientId: payload.clientId
        };
        tableName = "refresh_client_token";
        key = "clientId";
        columnKey='clientId';
    } else {
        obj = {
            userId: payload.id
        };
        tableName = "refresh_user_token";
        key = "id";
        columnKey='userId';
    }
    console.log(obj,tableName,key,payload[key])

    const refreshToken = jwtTokenGenerator(obj, refreshTokenValidity);

    insertRefreshToken(payload, refreshToken, tableName, key);
    return refreshToken;
}


function insertRefreshToken(payload, refreshToken, tableName, key) {

    var sql = `INSERT INTO ${tableName} (${columnKey}, refreshToken) VALUES (${payload[key]},'${refreshToken}')`;
    // console.log(sql)
    mysqldbconnection.query(sql, function (err, result) {
        if (err) throw util.errorOccured;
    });
}

exports.refreshToken1 = async function (req, res) {
    // console.log(req.body);

    const refreshToken = req.body.refreshToken;
    if (!refreshToken) {
        return res.status(403).send('Access is forbidden||');
    }

    try {
    // console.log("refreshToken",refreshToken)

        const newTokens = await refreshExpiredToken(refreshToken);
        // console.log("newTokens", newTokens)
        await res.send(newTokens);
    } catch (err) {
        // console.log(err)
        // const message = (err && err.message) || err;
        res.send(util.refreshTokenExpired);
    }
}

async function refreshExpiredToken(token) {
    // console.log("token",refreshToken)

    return new Promise((resolve, reject) => {
        const decodedToken = jwt.verify(token, jwtSecretString);
        let obj = {};
        let tableName = "";
        let key = "";
        if (hasClientId(decodedToken)) {
            obj = {
                clientId: decodedToken.clientId
            };
            tableName = "refresh_client_token";
            key = "clientId";
        } else {
            obj = {
                userId: decodedToken.userId
            };
            tableName = "refresh_user_token";
            key = "userId";
        }
       
        mysqldbconnection.query(`SELECT * FROM  ${tableName} where ${key}=${decodedToken[key]}`, async function (err, result, fields) {
            if (err) {
                throw err
            } else {
                if (!result.length) {
                   reject( new Error({message:"Access is forbidden",code:401}));
                } else {

                    const currentRefreshToken = await result.find(refreshToken => refreshToken.refreshToken == token);

                    if (!currentRefreshToken) {
                        resolve({
                            message: "Refresh token is wrong",
                            code: 403
                        })
                        // throw new Error(`Refresh token is wrong`);
                    } else {

                        // console.log("im in else")
                        // user's data for new tokens
                        // const payload = {
                        //     clientId: decodedToken[tableName],
                        // };

                        // get new refresh and access token
                        const newRefreshToken = await getUpdatedRefreshToken(obj, tableName, key);
                        const newAccessToken = exports.getAccessToken(obj);

                        resolve({
                            accessToken: newAccessToken,
                            refreshToken: newRefreshToken
                        });
                    }
                }
            };
        });
    });
}


function getUpdatedRefreshToken(payload, tableName, key) {
    // create new refresh token
    return new Promise((resolve, reject) => {

        const newRefreshToken = jwtTokenGenerator(payload, refreshTokenValidity);

        // let sql = `UPDATE coingames.refresh_token SET refreshToken='${newRefreshToken}' WHERE clientId=${payload.clientId} AND refreshToken='${oldRefreshToken}'`;
        // mysqldbconnection.query(sql, function (err, result) {
        //     if (err) throw err;
        //     console.log(result.affectedRows + " record(s) updated");
        // });
        insertRefreshToken(payload, newRefreshToken, tableName, key);
        // insertRefreshToken(payload, newRefreshToken);

        resolve(newRefreshToken);

    })

}