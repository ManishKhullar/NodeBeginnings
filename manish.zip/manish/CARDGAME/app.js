process.on('uncaughtException', function (err) {
  console.log(err);
});

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var cors = require('cors')
let util = require('./util.json');
const validateToken = require('./middleware/auth').validateToken;
global.sqlQueries = require('./sqlqueries.json');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var clientRouter = require('./routes/clients');
var loginRouter = require('./routes/loginRoute');
var transaction = require('./routes/transaction');
var generateGameNumber = require('./routes/gameNumber');
var gameList = require('./routes/gameList');



var mysql = require('mysql');

var pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'scriptlanes',
  database: 'coingames',
  insecureAuth: true
});

//connection.connect();
//global.mysqldbconnection = connection;
global.mysqldbconnection = {
  query: function () {
    var sql_args = [];
    var args = [];
    for (var i = 0; i < arguments.length; i++) {
      args.push(arguments[i]);
    }
    var callback = args[args.length - 1]; //last arg is callback
    pool.getConnection(function (err, connection) {
      if (err) {
        console.log(err);
        return callback(err);
      }
      if (args.length > 2) {
        sql_args = args[1];
      }
      connection.query(args[0], sql_args, function (err, results) {
        connection.release(); // always put connection back in pool after last query
        if (err) {
          console.log(err);
          return callback(err);
        }
        callback(null, results);
      });
    });
  }
};
//global.dbquery = dbquery;
console.log("Server started successfully");


var app = express();
app.use(cors());
// view engine setup
app.set('views', path.join(__dirname, 'views'));


app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({
  extended: false
}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, '/public/dist/card-games-admin')));


// app.use('/', indexRouter);
// validateToken
app.use('/api/users', usersRouter);
app.use('/api/client', clientRouter);
app.use('/api/transaction', transaction);
app.use('/api/gameNumber', validateToken, generateGameNumber);
app.use('/api/gameList', validateToken, gameList);


app.use('/api', loginRouter);

app.use('/', function (req, res) {
  res.sendFile(path.resolve('public/dist/card-games-admin/index.html'));
});

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;