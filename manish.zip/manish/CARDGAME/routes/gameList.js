var express = require('express');
var router = express.Router();

var gameController = require('../controller/gameListController');
var tokenValidation = require("../middleware/auth");
var jswService=require("../controller/jwt"); 


router.post('/joinGame',gameController.joinGame);



module.exports = router;
