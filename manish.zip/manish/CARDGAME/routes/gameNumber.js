var express = require('express');
var router = express.Router();

var gameNumberController = require('../controller/gameNumberController');
var tokenValidation = require("../middleware/auth");
var jswService=require("../controller/jwt"); 


router.post('/generateGameNumber',gameNumberController.generateGameNumber);



module.exports = router;
