var express = require('express');
var router = express.Router();

var loginController = require("../controller/loginRoute");

router.post('/clientlogin', loginController.clientLogin);

router.post('/userlogin', loginController.userLogin);

router.post('/getUserPassword', loginController.getUserPassword);

router.post('/getClientPassword', loginController.getClientPassword);

router.post('/logout', loginController.clientLogout);

module.exports = router;