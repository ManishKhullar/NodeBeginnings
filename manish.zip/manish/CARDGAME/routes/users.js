var express = require('express');
var router = express.Router();
var userController = require('../controller/users');
var jswService = require("../controller/jwt");



router.post('/adduser', userController.adduser);

router.post("/refreshToken", jswService.refreshToken1);

router.post('/getusers', userController.list);

router.post('/edituser', userController.editUser);

router.post('/disableagent', userController.disableAgent);

router.post('/disabledistributor', userController.disableDistributor);

router.post('/updatepassword', userController.updatePassword);

router.post('/getdistributors', userController.getDistributors);

router.post('/getagents', userController.getAgents);

router.post('/getUserbyId', userController.getUserById);

router.post('/getUserLoginLogs', userController.getUserLoginLogs);

module.exports = router;
