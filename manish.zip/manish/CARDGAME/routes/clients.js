var express = require('express');
var router = express.Router();

var clientController = require('../controller/clients');
var tokenValidation = require("../middleware/auth");
var jswService = require("../controller/jwt");

router.get('/testToken', tokenValidation.validateToken, clientController.testToken);

router.post("/refreshToken", jswService.refreshToken1);

router.post('/addclient', clientController.addClient);

router.post('/editclient', clientController.editClient);

router.post('/updatepassword', clientController.updatePassword);

router.post('/disableclient', clientController.disableClient);

router.post('/getCLients', clientController.getClientsByAgent);

router.post('/getClientLoginLogs', clientController.getClientLoginLogs);

module.exports = router;