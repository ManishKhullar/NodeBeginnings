var express = require('express');
var router = express.Router();
var transaction = require('../controller/transactionController');

router.post('/insertTransaction', transaction.manageTransaction);
router.post('/insertUserTransaction', transaction.insertUserTransaction);
router.post('/getTransactionDetailsByUser', transaction.getTransactions);



module.exports = router;