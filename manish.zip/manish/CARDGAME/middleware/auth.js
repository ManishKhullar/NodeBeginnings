const jwt = require('jsonwebtoken');
let config = require('../config.json');
let util = require('../util.json');
// module.exports = (req, res, next) => {
//   try {
//     const token = req.headers.authorization.split(' ')[1];
//     const decodedToken = jwt.verify(token, config.jwtpwd);
//     const userId = decodedToken.user;
//     if (!token) {
//       res.status(401).json({
//       error: new Error('Invalid request!')
//     });
//     } else {
//       next();
//     }
//   } catch(e) {
//     res.status(401).json({
//       error: new Error('Invalid request!')
//     });
//   }
// };

module.exports = {
  validateToken: (req, res, next) => {
console.log(req.headers.authorization)
    let token = req.headers.authorization;
    if (!token || !token.startsWith('Bearer')) {
      res.send(util.unauthorizedAccess);
    } else {

      // Remove Bearer from string
      token = token.slice(7, token.length);
      // console.log("req",token);

      if (token) {
        // req.headers.accessToken.split(' ')[1]; // Bearer <token>
        
        try {
          jwt.verify(token, config.jwtpwd, function(err, decoded) {
            // console.log(err, decoded) // bar
            if (err) {
              res.send(util.sessionExpired);
            } else {
              next();
            }
          });
          // 

        } catch (err) {
          // Throw an error just in case anything goes wrong with verification
          let result = {
            error: `Token Expired.`,
            status: 401
          };
          res.status(401).send(result);
          // throw new Error(err);
        }
      } else {
        let result = {
          error: `Authentication error. Token required.`,
          status: 402
        };
        res.status(402).send(result);
      }
    }
  }
};