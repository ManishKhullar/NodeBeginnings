function checkRequiredFields(data, requiredParams) {
    return new Promise(function (resolve, reject) {
        if (data === "") {
            reject.sendStatus({
                "ValidParams": false,
                "message": "Data Not Found"
            });
        }
        let validParams = true;
        let rouNo = 0;
        let fieldName = "";
        //to traverse the data 
        for (let j = 0; j < data.length; j++) {
            for (let i = 0; i < requiredParams.length; i++)
                if (data[j][requiredParams[i]] === undefined ||
                    data[j][requiredParams[i]] === "" ||
                    data[j][requiredParams[i]] === null) {
                    validParams = false;
                    rowNo = j + 1;
                    fieldName = requiredParams[i];
                    break;
                }
            if (!validParams) {
                break;
            }
        }

        let response = {
            "validParams": validParams,
            "message": "Required fields can not be left blank"
        }
        resolve(response);
    });
}